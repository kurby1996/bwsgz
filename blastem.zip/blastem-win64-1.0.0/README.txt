BlastEm 1.0.0
-------------

Installation
------------

Extract this archive to a directory of your choosing.

NOTE: Prior to version 0.4.1, BlastEm was still using Unixy locations for config
and save files. If you're upgrading from a previous version on Windows, you will
need to move them manually. For config files, the relevant paths are in the
previous paragraph. For save files, move all the directories found in
%userprofile%\.local\share\blastem to %localappdata%\blastem

Usage
-----

This version of BlastEm has a GUI that allows access to most configuration options.
Simply start BlastEm without passing a ROM filename on the command line to access
the main menu. You can also access the menu by hitting the button mapped to the ui.menu
action (default Esc).

If you explicitly request it, you can still use the old ROM-based UI instead. This UI does
not support configuration so you will need to modify the configuration file manually if you
use it. See the rest of this README for instructions on modifying the configuration file.

Some operations are currently only supported through the command line. To get a
list of supported command line options on Linux or OSX type:

    ./blastem -h

From within your BlastEm directory. On Windows type:

    blastem.exe -h

Lock-On Support
---------------

This version of BlastEm has some preliminary support for Sonic & Knuckles lock
on technology. This is available via both the menu and the command line. To use
it from the menu, first load Sonic & Knuckles normally. Enter the menu (mapped
to the Escape key by default) and select the "Lock On" option to select a ROM
to lock on. The system will then reload with the combined game. To use it from
the command line, specify the Sonic & Knuckles ROM as the primary ROM and
specify the ROM to be locked on using the -o option. As an example:

    ./blastem ~/romz/sonic_and_knuckles.bin -o ~/romz/sonic3.bin

Please note that Sonic 2 lock-on does not work at this time.

The lock-on menu option and command line switch are also used to combine a CD
image with a cartridge for Sega CD "Mode 1 Boot" scenarios as seen in titles
like Flux Mega CD and Doom 32X Resurrection Fusion. To use this feature, load
the cartridge as the main ROM and "lock-on" the CD image.

Configuration
-------------

Configuration is read from the file at $HOME/.config/blastem/blastem.cfg on
Unix-like systems and %localappdata%\blastem\blastem.cfg if it exists.
Othwerise it is read from default.cfg from the same directory as the BlastEm
executable. Sections are denoted by a section name followed by an open curly
bracket, the section's contents and a closing curly bracket. Individual
configuration values are set by entering the value's name followed by a space
or tab and followed by the desired value.

Bindings
--------

The keys subsection of bindings maps keyboard keys to gamepad buttons or UI
actions. The key name goes on the left and the action is on the right.
Most keys are named for the character they produce when pressed. For keys that
don't correspond to a normal character, check the list below:

  Name       | Description
  -----------------
  up           Up arrow
  down         Down arrow
  left         Left arrow
  right        Right arrow
  space
  tab
  backspace    Backspace on PC keyboards, Delete on Mac keyboards
  esc
  delete
  lshift       Left shift
  rshift       Right shift
  lctrl        Left control
  rctrl        Right control
  lalt         Left alt on PC keyboards, Option on Mac keyboards
  ralt         Right alt on PC keyboards, Option on Mac keyboards
  home
  end
  pageup
  pagedown
  f1
  f2
  f3
  f4
  f5
  f6
  f7
  f8
  f9
  f10
  f11
  f12
  select
  play
  search
  back
  np0          Number Pad 0
  np1          Number Pad 1
  np2          Number Pad 2
  np3          Number Pad 3
  np4          Number Pad 4
  np5          Number Pad 5
  np6          Number Pad 6
  np7          Number Pad 7
  np8          Number Pad 8
  np9          Number Pad 9
  np/          Number Pad /
  np*          Number Pad *
  np-          Number Pad -
  np+          Number Pad +
  npenter      Number Pad Enter
  np.          Number Pad .

The pads subsection is used to map gamepads and joysticks. Gamepads that are
recognized, can have their buttons and axes mapped with semantic names.
Xbox 360, PS4 and PS3 style names are supported. Unrecognized gamepads can be
mapped using numeric button and axis ids. The following button names are
recognized by BlastEm:
	a, cross
	b, circle
	x, square
	y, trinagle
	start, options
	back, select, share
	guide
	leftbutton, l1
	rightbutton, r1
	leftstick, l3
	rightstick, r3
The following axis names are recognized by BlastEm:
	leftx
	lefty
	rightx
	righty
	lefttrigger, l2
	righttrigger, r2


The mice subsection is used to map mice to emulated Mega/Sega mice. The default
configuration maps both the first and second host mice to the first emulated
mouse. This should not need modification for most users.

One special mapping deserves a mention. By default, the 'r' key is mapped to
ui.release_mouse. When operating in windowed mode the mouse has a capture
behavior. Mouse events are ignored until you click in the window. The mouse
will then be "captured" and the cursor will be both made invisible and locked
to the window. The ui.release_mouse binding releases the mouse so it can be
used normally.

UI Actions
----------

This section lists the various "UI" actions that can be triggered by a key or
gamepad binding.

ui.release_mouse             Releases the mouse if it is currently captured
ui.plane_debug               Toggles the VDP plane debug view
ui.vram_debug                Toggles the VDP VRAM debug view
ui.cram_debug                Toggles the VDP CRAM debug view
ui.compositing_debug         Toggles the VDP compositing debug view
ui.oscilloscope              Toggles an oscilloscope visualization
ui.cd_graphics_debug         Toggles the Sega CD graphics ASIC debug view
ui.vdp_debug_mode            Cycles the mode/palette of the VDP debug view
                             that currently has focus
ui.enter_debugger            Enters the debugger for the main CPU of the
							 currently emulated system
ui.screenshot                Takes an internal screenshot
ui.record_video              Toggles video recording. Videos are recorded as an
                             animated PNG paired with a WAV file.
ui.vgm_log                   Toggles VGM file logging
ui.menu                      Opens the in-game menu, or exits the menu if it
                             is currently open.
ui.exit                      Quits the emulator
ui.save_state                Saves a savestate to the quicksave slot
ui.load_state                Loads a savestate from the quicksave slot
ui.set_speed.N               Selects a specific machine speed specified by N
                             which should be a number between 0-9. Speeds are
                             specified in the "clocks" section of the config
ui.next_speed                Selects the next machine speed
ui.prev_speed                Selects the previous machine speed
ui.pause                     Pauses emulation
ui.advance                   Advances a single frame if paused. Pauses if not.
ui.toggle_fullscreen         Toggles between fullscreen and windowed mode
ui.soft_reset                Resets a portion of the emulated machine
                             Equivalent to pushing the reset button on the
                             emulated device
ui.reload                    Reloads the current ROM from a file and performs
                             a hard reset of the emulated device
ui.sms_pause                 Triggers a press of the pause button when in SMS
                             mode
ui.toggle_keyboard_captured  Toggles the capture state of the host keyboard
                             when an emulated keyboard is present
ui.release_mouse             Release the mouse from the captured state
ui.paste                     Pastes the contents of the clipboard into the
                             emulated system by simulating keypresses.
							 Currently, this is only implemented for SC-3000
ui.pause                     Pause emulation
ui.advance                   Advance emulation a single frame

Cassette Actions
----------------

When emulating the SC-3000, cassette emulation is supported via the lock-on
functionality. The following binding names can be triggered by a key or gamepad
binding.

cassette.play                Start playing the virtual tape
cassette.record              Starting recording on the virtual tape
cassette.stop                Stop the virtual tape at the current position
cassette.rewind              Rewind the virtual tape

IO
--

This section controls which peripherals are attached to the emulated console.
IO assignments can be overridden by the ROM database when appropriate. For
instance, games with mouse support can automatically use the mouse and games
that only support 3-button pads can automatically force an appropriate pad.
Unforunately, the ROM database is not yet exhaustive so manual configuration
may be needed here in some cases. The following IO devices are recognized

gamepad.2           SMS gamepad
gamepad.3           3-button Gen/MD gamepad
gamepad.6           6-button Gen/MD gamepad
heartbeat_trainer   Special peripheral used for the Heartbeat Personal Trainer
mouse               Sega/Mega mouse
saturn_keyboard     Saturn keybord or keyboard adapter
xband_keyboard      Xband keyboard
sega_parallel       PC Parallel port connection used by some of Sega's devtools
generic             Generic pipe-based device emulation for use with external
                    software.
serial              Generic pipe-based serial emulation
sega_multitap       Sega's 4-player Multitap
ea_multitap_port_a  First port of EA's 4-way Play multitap
ea_multitap_port_a  Second port of EA's 4-way Play multitap

Video
-----

The video section contains settings that affect the visual output of BlastEm.

"aspect" is used to control the aspect ratio of the emulated display. The
default of 4:3 matches that of a standard definition television.

"width" is used to control the window width when not in fullscreen mode.

"height" is used to control the window height when not in fullscreen mode. If
left unspecified, it will be calculated from "width" and "aspect".

"vertex_shader" and "fragment_shader" define the GLSL shader program that
produces the final image for each frame. Shaders can be used to add various
visual effects or enhancements. Currently BlastEm only ships with the default
shader and a "subtle" crt shader. If you write your own shaders, place them in
$HOME/.config/blastem/shaders and then specify the basename of the new shader
files in the "vertex_shader" and "fragment_shader" config options. Note that
shaders are not available in the SDL fallback renderer.

"scanlines" controls whether there is any emulation of the gaps between display
lines that are present when driving a CRT television with a 240p signal. This
emulation is very basic at the moment so this option is off by default.

"vsync" controls whether the drawing of frames is synchronized to the monitor
refresh rate. Valid values for this setting are "off", "on" and "tear". The
latter will attempt to use the "late tear" option if it's available and normal
vsync otherwise. Currently it's recommended to leave this at the default of
"off" as it may not work well with the default "audio" sync method and the
"video" sync method will automatically enable "vsync". See "Sync Source and
VSync" for more details.

"fullscreen" controls whether BlastEm starts in fullscreen or windowed mode.
This can be overridden on the command line with the -f flag. If fullscreen
is set to "off", -f will turn it on. Conversely, if fullscreen is set to "on"
in the config, -f will turn it off.

"gl" controls whether OpenGL is used for rendering. The default value is on.
If it is set to off instead, the fallback renderer which uses SDL2's render API
will be used instead. This option is mostly useful for users on hardware that
lacks OpenGL 2 support. While BlastEm will fall back automatically even if gl
is set to on there will be a warning. Disabling gl eliminates this warning.

"integer_scaling" controls whether the vertical video scaling ratio is forced
to be an integer value or not. When set to "off", the video output will fill
the screen vertically. When set to "on" the largest integer multiple that fits
will be used instead.

"scaling" controls the type of scaling used for textures in both the GL and
SDL renderers. Valid values are "nearest" and "linear". Note that shaders also
impact how pixels are scaled. This option is deprecated. Use the "sharp" shader
if you want sharp pixels rather than using "nearest".

"npot_textures" controls whether non-power of 2 textures are used. Some old GL
implementations don't support these or have a performance hit, but some weak
SoC GPUs seem to have better performance when this is turned on.

The "ntsc" and "pal" sub-sections control overscan settings for the emulated
video output for NTSC and PAL consoles respectively. More details are available
in the Overscan section. The "gamegear" section controls the video crop for
Game Gear games.

Overscan
--------

Analog televisions generally don't display the entirety of a video frame. Some
portion is cropped at the edges of the display. This is called overscan.
Unfortunately, the amount of cropping performed varies considerably and is even
adjustable on many TV sets. To deal with this, BlastEm allows overscan to be
customized.

Overscan values are specified in the "ntsc" and "pal" sub-sections of the
"video" section of the config file. The "overscan" sub-section contains four
settings for specifying the number of pixels cropped on each side of the
display: "top", "bottom", "left" and "right".

The default settings hide the horizontal border completely for both NTSC and
PAL consoles. For the vertical borders, the NTSC overscan settings are chosen
to give square pixels with the default aspect ratio of 4:3. For PAL, the
default settings are set so that the PAL-exclusive V30 mode will produce a
visible border that is the same size as what is shown in V28 mode in NTSC. This
results in a slightly squished picture compared to NTSC which is probably
appropriate given that a PAL display has more lines than an NTSC one.

Audio
-----

The audio section contains settings that affect the audio output of BlastEm.

"rate" selects the preferred sample rate for audio output. Your operating
system may not accept this value in which case a different rate will be chosen.
This should generally be either the native sample rate of your sound card or an
integral divisor of it. Most modern sound cards have a native output rate that
is a multiple of 48000 Hz so the default setting should work well for most users.

"buffer size" controls how large of a buffer uses for audio data. Smaller values
will reduce latency, but too small of a value can lead to dropouts. 512 works
well for me, but a higher or lower value may be more appropriate for your system.

"lowpass_cutoff" controls the cutoff, or knee, frequency of the RC-style
low-pass filter. The default value of 3390 Hz is supposedly what is present in
at least some Genesis/Megadrive models. Other models reportedly use an even
lower value.

"gain" specifies the gain in decibels to be applied to the overall output.

"fm_gain" specifies the gain to be applied to the emulated FM output before
mixing with the PSG.

"psg_gain" specifies the gain to be applied to the emulated PSG output before
mixing with the FM chip.

"rf5c164_gain" specifies the gain to be applied to the emulated Ricoh RF5C164
before mixing with other sources.

"cdda_gain" specifies the gain to be applied to CDDA tracks before mixing with
other sources.

"fm_dac" controls the characteristics of the DAC in the emulated FM chip. If
this is set to "linear", then the DAC will have precise linear output similar
to the integrated YM3438 in later Gen/MD consoles. If it is set to "zero_offset",
there will be a larger gap between -1 and 0. This is commonly referred to as the
"ladder effect". This will also cause "leakage" on channels that are muted or
panned to one side in a similar manner to a discrete YM2612.


Clocks
------

The clocks section contains settings that affect how fast things run.

"m68k_divider" describes the relationsip between the master clock (which is
53693175 Hz for NTSC mode and 53203395 Hz for PAL mode). The default value of 7
matches the real hardware. Set this to a lower number to overclock the 68000
and set it to a higher number to underclock it.

"max_cycles" controls how often the system is forced to synchronize all
hardware. BlastEm generally uses a sync on demand approach to synchronizing
components in the system. This can provide perfect synchronization for most
components, but since the Z80 can steal cycles from the 68000 at unpredictable
times 68000/Z80 synchronization is imperfect. The default value of 3420
corresponds to the number of master clock cycles per line. Larger numbers may
produce a modest performance improvement whereas smaller numbers will improve
68000/Z80 synchronization.

"speeds" controls the speed of the overall emulated console at different
presets. Preset 0 is the default speed and should normally be set to 100. The
other presets enable the slow/turbo mode functionality.

UI
--

The UI section contains settings that affect the user interface.

"rom" determines the path of the Genesis/Megadrive ROM that implements the UI.
Relative paths will be loaded relative to the BlastEm executable.

"initial_path" specifies the starting path for the ROM browser. It can contain
the following special variables: $HOME, $EXEDIR. Additionally, variables
defined in the OS environment can be used.

"remember_path" specifies whether BlastEm should remember the last path used in
the file browser. When it is set to "on", the last path will be remembered and
used instead of "initial_path" in subsequent runs. If it is set to "off",
"initial_path" will always be used.

"screenshot_path" specifies the directory "internal" screenshots will be saved
in. It accepts the same special variables as "initial_path".

"screenshot_template" specifies a template for creating screenshot filenames.
It is specified as a format string for the C library function strftime

"vgm_path" specifies the directory where VGM logs will be recorded

"vgm_template" specifies a template for creating VGM log filenames. It uses the
same format as "screenshot_template"

"save_path" specifies the directory that savestates, SRAM and EEPROM data will
be saved in for a given game. It can contain the following special variables:
$HOME, $EXEDIR, $USERDATA, $ROMNAME. Like "initial_path" it can also reference
variables from the environment.

"extensions" specifies the file extensions that should be displayed in the file
browser.

"state_format" specifies the preferred format for saving save states. Valid
values are "native" (the default) and "gst". "native" save states do a better
job of preserving the state of the emulated system, but "gst" save states are
compatible with other emulators like Kega and Gens. This setting has no effect
for systems other than the Genesis/Mega Drive

"use_native_filechooser" specifies whether the native file chooser or builtin
Nuklear UI file chooser will be used. This option has no effect on Mac OS.

Path Variables
--------------

This section explains the meaning of the special path variables referenced
in the previous section.

$HOME      The home directory of the current user. On most Unix variants, it
           will be a subdirectory of /home. On Windows it will typically be a
           subdirectory of C:\Users
$EXEDIR    The directory the BlastEm executable is located in
$USERDATA  This is an OS-specific path used for storing application specific
           user data. On Unix variants, it will be  $HOME/.local/share/blastem
           On Windows it will be %LOCALDATA%/blastem
$ROMNAME   The name of the currently loaded ROM file without the extension

System
------

"ram_init" determines how the RAM in the emulated system is initialized. The
default value of "zero" will cause all RAM to be zeroed out before the system
is started. Alternatively, "random" can be used to initialize RAM with values
from a pseudo-random number generator. This option is mostly useful for
developers that want to debug initialization issues in their code.

"default_region" determines the console region that will be used when region
detection fails and when there are multiple valid regions. The default of 'U'
specifies a 60Hz "foreign" console.

"sync_source" controls whether BlastEm uses audio or video output to control
execution speed. "video" can provide a smoother experience when your display
has a similar refresh rate to the emulated system, but has some limitations
in the current version. The default value is "audio".

"megawifi" enables or disables support for MegaWiFi cart emulation. MegaWiFi
is a cartridge that contains WiFi hardware for network functionality. Enabling
this means that ROMs potentially have access to your network (and the internet)
which obviously has security implications. For this reason, it is disabled by
default. If you wish to try out MegaWiFi emulation, set this to "on". Note that
the support for MegaWiFi hardware is preliminary in this release.

"model" selects wich model of Genesis/Mega Drive is emulated. This feature is
still a work in progress and not all model quirks are currently implemented.

Debugger
--------

BlastEm has an integrated command-line debugger loosely based on GDB's
interface. It contains a turing complete language to support complex
breakpoint conditions and to allow some basic scripting. 

The -d flag can be used to cause BlastEm to start in the debugger.
Alternatively, you can use the ui.enter_debugger action (mapped to the 'u' key
by default) to enter the debugger while a game is running. To debug the menu
ROM, use the -dm flag.


Top level debugger commands take the following form:

    COMMAND[/FORMAT_CHAR] [ARGS]
	
Where COMMAND is the name of the command, an unambiguous prefix or an explict
alias. FORMAT_CHAR is a single character specifying the desired format for
certain commands. ARGS is a list of arguments separated by spaces. Arguments
must be syntactically valid as an expression and are generally evaluated as
such, but there are some exceptions. For instance, the "function" command
expects its first argument to be the bare name of the function. This is used
directly rather than evaluated.

To get a list of commands valid in the current context use the help command.
The help command will also list explicit aliases for a command and its expected
arguments.

The commands available in all contexts are:
    quit
	help
	breakpoint ADDRESS             Add a new breakpoint at ADDRESS for the
	                               current CPU
    watchpoint ADDRESS [SIZE]      Set a watchpoint at ADDRESS with an optional
	                               size in bytes. If not specified, the default
								   size is context dependent.
	continue                       Resume execution
	advance ADDRESS                Resume execution until ADDRESS is reached
	step                           Advance to the next instruction, stepping
	                               into subroutines.
	next                           Advance to the next instruction, stepping
	                               over subroutine calls.
	over                           Similar to next, but ignores branches to
	                               a lower address. Good for skipping over
								   loops.
	backtrace                      Attempts to print a backtrace. Note that
	                               this uses heuristics and will not provide
								   correct results in all cases.
	frames EXPRESSION              Resume execution for EXPRESSION video frames
	print[/FORMAT] EXPRESSION      Print the value of EXPRESSION using FORMAT
	printf FORMAT EXPRESSION...    Basically the same as the C function
	softreset                      Equivalent to the ui.soft_reset binding
	display[/FORMAT] EXPRESSION... Print one ore more expressions every time
	                               this debug context is entered
    deletedisplay                  Removes an entry added via "display"
	commands BREAKPOINT            Set a list of commands to execute when a
	                               breakpoint is hit. End the list with "end"
	function NAME [ARGS...]        Creates a user-defined named NAME with
								   arguments ARGS. Enter the body of the
								   function on subsequent lines. End with "end"
    return VALUE                   Returns a value inside a function
	set MEM|NAME VALUE             Sets a register, symbol or memory location
	                               to VALUE
	variable NAME [VALUE]          Create a new variable called NAME and set it
	                               to VALUE or 0 if no value provided
	array NAME [VALUE...]          Create a new array called NAME if it doesn't
								   already exist. The array is initialized with
								   the remaining parameters.
    append NAME VALUE              Appens VALUE to the array NAME
	bindup NAME                    Simulate a keyup for binding NAME
	binddown NAME                  Simulate a keydown for binding NAME

For a list of functions available in specific contexts, use the builtin help
command.

Debugger expressions are formed from literals, operators, paren grouping, array
access and function calls.

The following types of literals are supported:
 - Decimal integers
 - Hex integers using 0x and $ prefixes
 - Strings surrounded by "
 - Floating point numbers

The following operators are available:
 + addition
 - subtraction, unary negation
 * multiplication
 / division
 & bitwise and
 | bitwise or
 ^ bitwise xor
 = equality checking
 != inequality checking
 > greater than
 >= greater equal
 < less than
 <= less equal
 ! logical not
 ~ bitwise not

The following builtin functions are available:
	sin, cos, tan, asin, acos, atan, atan2: sames as their C equivalents
	pop: pops a value from the end of an array
	size: returns the size of an array

GDB Remote Debugging
--------------------

In addition to the native debugger, BlastEm can also act as a GDB remote
debugging stub. To use this, you'll want to configure your Makefile to produce
both an ELF executable and a raw binary. Invoke an m68k-elf targeted gdb with
the ELF file. Once inside the gdb session, type:

    target remote | BLASTEM_PATH/blastem ROM_FILE.bin -D

where BLASTEM_PATH is the relative or absolute path to your BlastEm
installation and ROM_FILE.bin is the name of the raw binary for your program.
BlastEm will halt at the beginning of your program's entry point and return
control to GDB. This will allow you to set breakpoints before your code runs.

On Windows, the procedure is slightly different. First run
    blastem.exe ROM_FILE.bin -D
This will cause BlastEm to wait for a socket connection on port 1234. It will
appear to be frozen until gdb connects to it. Now open the ELF file in gdb
and type:

    target remote :1234

Trace points and watch points are not currently supported.

Included Tools
--------------

BlastEm ships with a few small utilities that leverage portions of the emulator
code.

    dis       - 68K disassembler
    zdis      - Z80 disassembler

Note that the Windows build no longer includes these due to Windows Defender
false positives.

Sync Source and VSync
-----

This section includes information about using VSync with BlastEm. Currently,
the best way to use VSync is to set the sync source to "video". This will force
VSync on and use video output for controlling the speed of emulation. In this
mode, audio will have it's rate automatically adjusted to keep pace with video.
The code for this is still a bit immature, so you may experience dropouts or
pitch changes in this mode.

If you experience problems, please switch back to the "audio" sync source,
which is the default. You can also enable vsync when using the "audio" sync
source by changing the "vsync" setting. This will generally work okay as long
as the emulated refresh rate is below your monitor refresh rate (even if only
slightly), but you will occassionally get a doubled frame (or frequently if
the refresh rates are very different).

Turbo mode will currently not work when vsync is on, regardless of which sync
source is used. Slow mode will work with "audio" sync, but not "video" sync.

--------------

My work has been made much easier by the contributions of those in the Genesis
community past and present. I'd like to thank the people below for their help.

Nemesis            - His work reverse engineering and documenting the VDP and
                     YM-2612 has saved me an immeasurable amount of time. I've
                     found both his sprite overflow test ROM and VDP FIFO
                     Testing ROM to be quite helpful.

Charles MacDonald  - While it hasn't been updated in a while, I still find his
                     VDP document to be my favorite reference. His Genesis
                     hardware document has also come in handy.

Eke-Eke            - Eke-Eke wrote a great document on the use of I2C EEPROM in
                     Genesis games and also left some useful very helpful
                     comments about problematic games in Genesis Plus GX

Sauraen            - Sauraen has analyzed the YM2203 and YM2612 dies and written
                     a VHDL operator implementation. These have been useful in
                     improving the accuracy of my YM2612 core.

Alexey Khokholov   - Alexey (aka Nuke.YKT) has analyzed the YM3438 die and written
                     a fairly direct C implementation from that analysis. This
                     has been a useful reference for verifying and improving my
                     YM2612 core.

Bart Trzynadlowski - His documents on the Genecyst save-state format and the
                     mapper used in Super Street Fighter 2 were definitely
                     appreciated.

KanedaFR           - Kaneda's SpritesMind forum is a great resource for the
                     Sega development community.

Titan              - Titan has created what are without a doubt the most
                     impressive demos on the Megadrive. Additionally, I am very
                     grateful for the documentation provided by Kabuto and the
                     assistance of Kabuto, Sik and Jorge in getting Overdrive 2
                     to run properly in BlastEm.

flamewing          - flamewing created a very handy exhaustive test ROM for 68K
                     BCD instructions and documented the proper behavior for
                     certain BCD edge cases

r57shell           - r57shell created a test ROM for 68K instruction sizes that
                     was invaluable in fixing the remaining bugs in my 68K instruction
                     decoder

I'd also like to thank the following people who have performed compatibility
testing or submitted helpful bug reports

micky, Sasha, lol-frank, Sik, Tim Lawrence, ComradeOj, Vladikcomper

I have unfortunately not been good of keeping track of this since the 0.6.2
release. I have received help from quite a few people since, but have stopped
updating this list. If you're one of those people please accept my apologies
and know that your help is definitely still appreciated.

License
-------

BlastEm is free software distributed under the terms of the GNU General Public
License version 3 or higher. This gives you the right to redistribute and/or
modify the program as long as you follow the terms of the license. See the file
COPYING for full license details.

Binary releases of BlastEm are packaged with GLEW, SDL2 and zlib which have their
own licenses. See GLEW-LICENSE and SDL-LICENSE for details. For zlib license
information, please see zlib/zlib.h or zlib/LICENSE in the source code release.
